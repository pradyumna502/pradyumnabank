﻿using System;

namespace Exam2_CarRental
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            ShowMainMenu();
        }

        public static void ShowAllCustomers()
        {
            foreach (Customer myCustomer in CarRental.AllCustomers)
            {
                Console.WriteLine("Name: {0}, Id:{1}", myCustomer.Name, myCustomer.CusId);
            }
            Console.ReadLine();
            MainClass.ShowMainMenu();
        }
        public static void ShowMainMenu()
        {
            Console.Clear();
            Console.WriteLine("-------------------");
            Console.WriteLine("1: Create customer");
            Console.WriteLine("2: Exit");
            Console.WriteLine("3: Show customer");
            Console.WriteLine("-------------------");
            string command = Console.ReadLine();

            switch (command)
            {
                case "1":
                    CreateCustomer();
                    break;
                case "2":
                    Environment.Exit(-1);
                    break;
                case "3":
                    ShowAllCustomers();
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    Console.ReadLine();
                    ShowMainMenu();
                    break;
            }
        }
        public static int accountNumberMarker = 1000;

        public static void CreateCustomer()
        {
            Console.Clear();
            Console.WriteLine("----------------------------------");
            Console.WriteLine("New Customer");
            Console.WriteLine("----------------------------------");
            Console.WriteLine();
            Console.Write("Please enter the Name: ");
            string name = Console.ReadLine();
            int id = ++accountNumberMarker;
            Customer customer = new Customer();
            customer.Name = name;
            customer.CusId = id;
            CarRental.AllCustomers.Add(customer);
            Console.ReadLine();
            MainClass.ShowMainMenu();
        }
       


    }
}
