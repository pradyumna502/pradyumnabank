﻿namespace Exam2_CarRental
{
    public interface IElectric
    {
        void ElectricDiscount();
    }
}
