﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2_CarRental
{
    class CarRental
    {
        private static List<Customer> customers = new List<Customer>();
        public CarRental()
        {
            customers = new List<Customer>();
        }
        public static List<Customer> AllCustomers
        {
            get { return customers; }
        }
    }
    
}
