﻿using System.Collections.Generic;

namespace Exam2_CarRental
{
    public class Truck : Car
    {

        private string Capacity;
        private List<Truck> truckList = new List<Truck>();

        //Truck constructor with parameters
        public Truck(string capacity, int plate, double price) : base(plate, price)
        {
            Capacity = capacity;
        }

        //Empty Tuck constructor
        public Truck() : base()
        {

        }


    }
}
