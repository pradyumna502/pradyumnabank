﻿using System;
namespace Exam2_CarRental
{
    public class Rental : IRentDiscount
    {
        private DateTime StartDate;
        private DateTime ReturnDate;
        private Car GetCar;
        private Customer GetCustomer;
        private bool Status;


        //Constructors
        public Rental()
        {
        }

        public Rental(DateTime startDate, DateTime returnDate = default, Car getCar = null, Customer getCustomer = null, bool status = false)
        {
            StartDate = startDate;
            ReturnDate = returnDate;
            GetCar = getCar;
            GetCustomer = getCustomer;
            Status = status;
        }



        /*Check Progress of rented Car to display start and end date
        User inputs Car plate to get this info
         */
        public void getStatus(string carPlate)
        {

        }

        /*
         Display a list of all Cars that are rented
         */
        public void listRentedCars()
        {

        }

        /*
         Display a list of all available Cars that are not rented
         */
        public void listAvailableCars()
        {

        }

        //Rent Car
        public void rentCar(DateTime startRent, DateTime endRent, Car type)
        {

        }

        //End rent
        public void completeRent()
        {

        }

        public void OverOneWeekDiscount()
        {
            StartDate = ReturnDate.AddDays(7);
            //discount of 10%

        }

    }
}
