﻿using System.Collections.Generic;

namespace Exam2_CarRental
{
    public class Customer
    {
        public string Name { get; set; }
        public int CusId { get; set; }
       
        private static List<Rental> rentals = new List<Rental>();

        public Customer()
        {

        }
        public Customer(string name)
        {
            Name = name;
            //Instantiating a list of rentals
            rentals = new List<Rental>();
        }

        //Rent a Car
        public void rentCar()
        {

        }


        //Return Car, finish rent period
        public void finishRent()
        {

        }



    }
}
