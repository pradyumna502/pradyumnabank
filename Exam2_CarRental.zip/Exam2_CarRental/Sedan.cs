﻿using System.Collections.Generic;


namespace Exam2_CarRental
{



    public class Sedan : Car, IElectric
    {

        private string Seats;
        private bool isElectric;
        private List<Sedan> sedanList = new List<Sedan>();




        //Sedan constructor with parameters
        public Sedan(string seats, int plate, double price) : base(plate, price)
        {
            Seats = seats;
        }

        //Empty Sedan constructor
        public Sedan() : base()
        {

        }

        public void ElectricDiscount()
        {
            //Price -= 0.10;
        }
    }
}
