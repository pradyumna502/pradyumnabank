﻿namespace Exam2_CarRental
{
    public interface IRentDiscount
    {
        void OverOneWeekDiscount();
    }
}
