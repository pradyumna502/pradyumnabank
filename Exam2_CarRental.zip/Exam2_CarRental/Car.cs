﻿using System;
using System.Collections.Generic;

namespace Exam2_CarRental
{
    public enum Maker { SAAB, Volvo, Tesla, Tata };

    public abstract class Car
    {
        //Member variables to be inherited to child classes of Sedan and Truck
        protected int Plate;
        protected double Price;
        //private static Maker maker;
        private Rental _rental; //this is to have a composite relation to Rentals
        private Maker brand;

        //static modifier is shared between all the objects
        //list is a dynamic array(Collection class)
        private static List<Rental> rentals = new List<Rental>();
        private static List<Sedan> sedans = new List<Sedan>();
        private static List<Truck> trucks = new List<Truck>();
        

        //Constructor

        protected Car()
        {
            sedans = new List<Sedan>();
            trucks = new List<Truck>();
        }

        public static List<Sedan> AllSedans
        {
            get { return sedans; }
        }

        public static List<Truck> AllTrucks
        {
            get { return trucks; }
        }


        public Car(int plate, double price, Maker brand, Rental rental)
        {
            Plate = plate;
            Price = price;
            this.brand = brand;
            _rental = rental;

            //Instantiating a list of rentals
            rentals = new List<Rental>();
        }

        protected Car(int plate, double price)
        {
            Plate = plate;
            Price = price;
        }







        //property method to get a list of rentals,
        public static List<Rental> AllRentals
        {
            get
            {
                return rentals;
            }
        }
    }
}
